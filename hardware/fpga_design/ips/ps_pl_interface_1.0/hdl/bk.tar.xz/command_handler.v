`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/23/2024 08:43:49 AM
// Design Name: 
// Module Name: command_handler
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module command_handler #(parameter C_AXI_Light_Slave_DATA_WIDTH = 32, parameter BUFF_LEN = 20) (
    input wire clk,
    input wire[(C_AXI_Light_Slave_DATA_WIDTH*BUFF_LEN) - 1: 0] received_data,
    input wire [BUFF_LEN-1:0] write_map,
    output reg [3:0] read_map,

    output reg [7:0]   cmd,
    output reg [15:0]  init_value,
    output reg [15:0]  puf_value,
    output reg [31:0]  start_addr,
    output reg [31:0]  stop_addr,
    output wire cmd_ready,

    output reg[7:0] puf_type,
    output reg      ce_driven,

    // Default Timing
    output reg[15:0]   tWaitAfterInit,
    output reg[15:0]   tNextRead,
    output reg[15:0]   tStartDefault,
    output reg[15:0]   tnextWriteDefault,
    output reg[15:0]   tACDefault,
    output reg[15:0]   tASDefault,
    output reg[15:0]   tAHDefault,
    output reg[15:0]   tPWDDefault,
    output reg[15:0]   tDSDefault,
    output reg[15:0]   tDHDefault,

    // Write Latency
    output reg[15:0]   tNextWriteAdjusted,
    output reg[15:0]   tStartAdjusted,
    output reg[15:0]   tACAdjusted,
    output reg[15:0]   tASAdjusted,
    output reg[15:0]   tAHAdjusted,
    output reg[15:0]   tDSAdjusted,
    output reg[15:0]   tDHAdjusted,
    output reg[15:0]   tPWDAdjusted,

    // Row-Hammering
    output reg[15:0] hammeringIterations,
    output reg[15:0] hammeringDistance,
    output reg[15:0] tWaitBetweenHammering
);


    initial begin

        // General PUF definitions
        puf_type <= 8'h0;
        init_value <= 16'h0;
        puf_value <= 16'h0;
        start_addr <= 32'h00;
        stop_addr <= 32'h00;
        ce_driven <= 0;

        // Timing
        tWaitAfterInit <= 15'h0;
        tNextRead <= 15'h0;
        tStartDefault <= 15'h0;
        tnextWriteDefault <= 15'h0;
        tACDefault <= 15'h0;
        tASDefault <= 15'h0;
        tAHDefault <= 15'h0;
        tPWDDefault <= 15'h0;
        tDSDefault <= 15'h0;
        tDHDefault <= 15'h0;

        tNextWriteAdjusted <= 15'h0;
        tStartAdjusted <= 15'h0;
        tACAdjusted<= 15'h0;
        tASAdjusted<= 15'h0;
        tAHAdjusted<= 15'h0;
        tDSAdjusted<= 15'h0;
        tDHAdjusted<= 15'h0;
        tPWDAdjusted<= 15'h0;

        // Row-Hammering
        hammeringIterations <= 16'h0;
        hammeringDistance <= 16'h0;
        tWaitBetweenHammering <= 16'h0;
    end



    reg [(C_AXI_Light_Slave_DATA_WIDTH*BUFF_LEN)-1:0] command_buffer;
    reg [11:0] buffer_ctr = 12'h0;
    reg flush_buffer = 1'b0;

    reg[7:0] tmp_cmd = 0;
    reg flush_cmd = 0;

    localparam RESET = 8'h00;
    localparam START_TEST = 8'h01;


    localparam RELIABLE      = 8'h00;
    localparam WRITE_LATENCY = 8'h01;
    localparam READ_LATENCY  = 8'h02;
    localparam ROW_HAMMERING = 8'h03;

    task setDefaultTimingParameters;
        begin
            ce_driven <= (received_data[23:16] > 8'h0) ? 1'b1 : 1'b0;
            if(write_map[1] == 1) begin
                tWaitAfterInit <= received_data[39:24];
                tNextRead <= received_data[55:40];
                if(write_map[2] == 1) begin
                    tStartDefault <= received_data[71:56];
                    tnextWriteDefault <= received_data[87:72];
                    tACDefault <= received_data[87:72];
                end
                if(write_map[3] == 1) begin
                    tASDefault <= received_data[103:88];
                    tAHDefault <= received_data[119:104];
                end
                if(write_map[4] == 1) begin
                    tPWDDefault <= received_data[135:120];
                    tDSDefault <= received_data[151:136];
                end
                if(write_map[5] == 1) begin
                    tDHDefault <= received_data[167:152];
                    init_value <= received_data[183:168];
                end
                if(write_map[6] == 1) begin
                    puf_value <= received_data[199:184];
                end
                if(write_map[7] == 1) begin
                    start_addr <= received_data[231:200];
                end
                if(write_map[8] == 1) begin
                    stop_addr <= received_data[263:232];
                    if(puf_type == RELIABLE)
                        flush_cmd <= 1'b1;
                end
            end
        end
    endtask


    task setParametersRowHammering;
        begin
            if(write_map[8] == 1) begin
                hammeringIterations  <= received_data[279:264];
            end
            if(write_map[9] == 1) begin
                hammeringDistance  <= received_data[295:280];
                tWaitBetweenHammering <= received_data[311:296];
                flush_cmd <= 1'b1;
            end
        end
    endtask


    task setParametersWriteLatency;
        begin
            if(write_map[8] == 1) begin
                tNextWriteAdjusted <= received_data[279:264];
            end
            if(write_map[9] == 1) begin
                tStartAdjusted <= received_data[295:280];
                tACAdjusted  <= received_data[311:296];
            end
            if(write_map[10] == 1) begin
                tASAdjusted  <= received_data[327:312];
                tAHAdjusted  <= received_data[343:328];
            end
            if(write_map[11] == 1) begin
                tDSAdjusted  <= received_data[359:344];
                tDHAdjusted  <= received_data[375:360];
            end
            if(write_map[12] == 1) begin
                tPWDAdjusted <= received_data[391:376];
                flush_cmd <= 1'b1;
            end
        end
    endtask


    always @ (posedge clk) begin
        if(flush_cmd == 0) begin
            if(write_map[0] == 1) begin
                cmd <= received_data[7:0];
                if(received_data[7:0] == START_TEST) begin
                    puf_type <= received_data[15:8];
                    setDefaultTimingParameters();
                    if(received_data[15:8] == ROW_HAMMERING) begin
                        setParametersRowHammering();
                    end

                    if(received_data[15:8] == WRITE_LATENCY) begin
                        setParametersWriteLatency();
                    end

                end

                if(received_data[7:0] == RESET) begin

                end
            end
        end else begin 
            flush_cmd <= 1'h0;
        end
    end



    /** 
     * Always block to buffer the input values
     */
    /*    always @(posedge clk) begin
        if (flush_cmd == 1'b1 || flush_buffer == 1'b1) begin
            command_buffer <= {C_AXI_Light_Slave_DATA_WIDTH*BUFF_LEN{1'b0}};
            read_map <= 4'b0;
            buffer_ctr <= 12'h0;
            flush_buffer <= 0;
        end
        else begin
            if (write_map[0] == 1 && read_map[0] == 1'b0) begin
                command_buffer[(buffer_ctr * C_AXI_Light_Slave_DATA_WIDTH * 4) +: C_AXI_Light_Slave_DATA_WIDTH] = slv_reg0;
                read_map[0] <= 1'b1;
            end

            if (write_map[1] == 1 && read_map[1] == 1'b0) begin
                command_buffer[(buffer_ctr * C_AXI_Light_Slave_DATA_WIDTH * 4) + C_AXI_Light_Slave_DATA_WIDTH +: C_AXI_Light_Slave_DATA_WIDTH] = slv_reg1;
                read_map[1] <= 1'b1;
            end

            if (write_map[2] == 1 && read_map[2] == 1'b0) begin
                command_buffer[(buffer_ctr * C_AXI_Light_Slave_DATA_WIDTH * 4) + (2 * C_AXI_Light_Slave_DATA_WIDTH) +: C_AXI_Light_Slave_DATA_WIDTH] = slv_reg2;
                read_map[2] <= 1'b1;
            end

            if (write_map[3] == 1 && read_map[3] == 1'b0) begin
                command_buffer[(buffer_ctr * C_AXI_Light_Slave_DATA_WIDTH * 4) + (3 * C_AXI_Light_Slave_DATA_WIDTH) +: C_AXI_Light_Slave_DATA_WIDTH] = slv_reg3;
                read_map[3] <= 1'b1;
            end

            if(buffer_ctr < BUFF_LEN) begin
                if(read_map == 4'b1111) begin
                    buffer_ctr <= buffer_ctr + 12'h1;
                    read_map <= 4'h0;
                end
            end
            else begin
                flush_buffer <= 1;
            end
        end
    end

    localparam   CMD_UNDEFINED 		   = 8'hff;
    localparam   CMD_IDN 			   = 8'h01;
    localparam   CMD_START_MEASUREMENT = 8'h02;
    localparam   CMD_STOP_MEASUREMENT  = 8'h03;
    localparam   CMD_RETRIEVE_STATUS   = 8'h04;
    localparam   CMD_RESET             = 8'h05;


    reg[7:0]   tmp_measure_type = 8'h0;
    reg[15:0]  tmp_init_value   = 16'h0;
    reg[31:0]  tmp_start_addr   = 32'h0;
    reg[31:0]  tmp_stop_addr    = 32'h0;
    reg[32:0]  tmp_time_value   = 32'h0;
    reg[127:0] tmp_auxilary_data = 32'h0;


    reg flush_cmd = 1'b0;

    always @ (posedge clk) begin
        if (buffer_ctr == 12'h1) begin
            tmp_cmd  <= command_buffer[0+:8];
        end
        else if (buffer_ctr == 12'h2)
            begin
                if (read_map == 4'b1111) begin
                    if(tmp_cmd  == CMD_START_MEASUREMENT) begin
                        tmp_measure_type <= command_buffer[8+:8]; // Identifies the measure type, e.g. read- or write-latency measurement
                        tmp_init_value <= command_buffer[16+:16];
                        tmp_start_addr <= command_buffer[32+:32];
                        tmp_stop_addr <= command_buffer[64+:32];
                        tmp_time_value <= command_buffer[96+:32];
                        tmp_auxilary_data <= command_buffer[128+:128];
                        flush_cmd <= 1'b1;
                    endta
                    else
                        tmp_measure_type    <= 8'h0;
                    tmp_init_value      <= 16'h0;
                    tmp_start_addr      <= 32'h0;
                    tmp_stop_addr       <= 32'h0;
                    tmp_time_value      <= 32'h0;
                    tmp_auxilary_data   <= 32'h0;
                    flush_cmd <= 1'b0;
                end
            end
        else if (buffer_ctr > 12'h2) begin
            tmp_measure_type    <= 8'hff;
            tmp_init_value      <= 16'hffff;
            tmp_start_addr      <= 32'hffffffff;
            tmp_stop_addr       <= 32'hffffffff;
            tmp_time_value      <= 32'hffffffff;
            tmp_auxilary_data   <= 32'hffffffff;
        end
    end

    assign measure_type = tmp_measure_type;
    assign init_value = tmp_init_value;
    assign start_addr = tmp_start_addr;
    assign stop_addr = tmp_stop_addr;
    assign time_value = tmp_time_value;
    assign auxilary_data = tmp_auxilary_data;
    assign cmd = tmp_cmd;
    assign buffer_ctr_tmp = buffer_ctr;*/
    assign cmd_ready = flush_cmd;
endmodule
